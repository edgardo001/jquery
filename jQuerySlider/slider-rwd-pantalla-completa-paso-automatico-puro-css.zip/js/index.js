/*
Al añadir contenido fuera del header se muestra con efecto parallax
artículo explicativo en el blog:
http://escss.blogspot.com/2013/05/slider-rwd-pantalla-completa.html
*/